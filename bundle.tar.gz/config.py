import os

debug = True

secretKey = os.urandom(24) 

statePath = "alarm.json"


port = 86

threaded=True

host = "0.0.0.0"


